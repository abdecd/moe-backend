package com.abdecd.moebackend.common.constant;

public class VideoGroupConstant {
    public static final Byte COMMON_VIDEO_GROUP = 0;
    public static final Byte ANIME_VIDEO_GROUP = 1;
    public static final Double DEFAULT_WEIGHT = 1.0;
}
