package com.abdecd.moebackend.business.service.report;


import com.abdecd.moebackend.business.pojo.dto.report.AddReportDTO;

public interface ReportService {
    Long addReport(AddReportDTO addReportDTO);
}

