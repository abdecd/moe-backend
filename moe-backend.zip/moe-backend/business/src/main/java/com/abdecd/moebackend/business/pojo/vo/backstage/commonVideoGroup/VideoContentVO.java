package com.abdecd.moebackend.business.pojo.vo.backstage.commonVideoGroup;

import lombok.Data;

import java.util.ArrayList;

@Data
public class VideoContentVO {
    private ArrayList<VideoVo> videoVoArrayList;
}

