package com.abdecd.moebackend.business.pojo.vo.backstage.commonVideoGroup;

import lombok.Data;

@Data
public class VideoVo{
    private String videoId;
    private String videoGroupId;
    private String index;
    private String title;
    private String videoCover;
}
