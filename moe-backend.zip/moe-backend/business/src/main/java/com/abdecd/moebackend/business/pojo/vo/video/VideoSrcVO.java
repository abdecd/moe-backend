package com.abdecd.moebackend.business.pojo.vo.video;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class VideoSrcVO {
    private String srcName;
    private String src;
}
