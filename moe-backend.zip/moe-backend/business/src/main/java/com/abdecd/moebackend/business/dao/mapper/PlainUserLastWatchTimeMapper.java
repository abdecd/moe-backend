package com.abdecd.moebackend.business.dao.mapper;

import com.abdecd.moebackend.business.dao.entity.PlainUserLastWatchTime;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PlainUserLastWatchTimeMapper extends BaseMapper<PlainUserLastWatchTime> {
}
